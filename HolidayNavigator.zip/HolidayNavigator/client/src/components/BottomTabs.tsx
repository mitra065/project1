import { useLocation, useRoute, Link } from "wouter";

export default function BottomTabs() {
  const [location] = useLocation();
  const [isHome] = useRoute("/");
  const [isSettings] = useRoute("/settings");
  const [isHelp] = useRoute("/help");
  const [isAdmin] = useRoute("/admin");
  const [isAdminPaper] = useRoute("/admin-paper");

  return (
    <footer className="md:hidden bg-white border-t border-neutral-200 flex">
      <Link href="/">
        <div className={`rn-pressable flex-1 flex flex-col items-center py-3 cursor-pointer ${isHome ? 'text-primary' : 'text-neutral-300'}`}>
          <span className="material-icons text-xl">calendar_today</span>
          <span className="text-xs mt-1">Calendar</span>
        </div>
      </Link>
      <Link href="/?view=list">
        <div className={`rn-pressable flex-1 flex flex-col items-center py-3 cursor-pointer ${location === '/?view=list' ? 'text-primary' : 'text-neutral-300'}`}>
          <span className="material-icons text-xl">list</span>
          <span className="text-xs mt-1">List</span>
        </div>
      </Link>
      <Link href="/?filter=true">
        <div className={`rn-pressable flex-1 flex flex-col items-center py-3 cursor-pointer ${location === '/?filter=true' ? 'text-primary' : 'text-neutral-300'}`}>
          <span className="material-icons text-xl">filter_list</span>
          <span className="text-xs mt-1">Filter</span>
        </div>
      </Link>
      <Link href="/settings">
        <div className={`rn-pressable flex-1 flex flex-col items-center py-3 cursor-pointer ${isSettings ? 'text-primary' : 'text-neutral-300'}`}>
          <span className="material-icons text-xl">settings</span>
          <span className="text-xs mt-1">Settings</span>
        </div>
      </Link>
      <Link href="/admin">
        <div className={`rn-pressable flex-1 flex flex-col items-center py-3 cursor-pointer ${isAdmin ? 'text-primary' : 'text-neutral-300'}`}>
          <span className="material-icons text-xl">admin_panel_settings</span>
          <span className="text-xs mt-1">Admin</span>
        </div>
      </Link>
      <Link href="/admin-paper">
        <div className={`rn-pressable flex-1 flex flex-col items-center py-3 cursor-pointer ${isAdminPaper ? 'text-primary' : 'text-neutral-300'}`}>
          <span className="material-icons text-xl">description</span>
          <span className="text-xs mt-1">Paper UI</span>
        </div>
      </Link>
    </footer>
  );
}
