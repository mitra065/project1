import { useState, useEffect } from "react";
import { Holiday } from "../lib/types";
import { getHolidaysForDate, formatMonth } from "../lib/utils";

interface CalendarViewProps {
  holidays: Holiday[];
  year: number;
  month: number;
  onMonthChange: (month: number) => void;
}

export default function CalendarView({ holidays, year, month, onMonthChange }: CalendarViewProps) {
  const [calendarDays, setCalendarDays] = useState<Array<{ date: Date | null; day: number; isCurrentMonth: boolean }>>([]);
  
  useEffect(() => {
    generateCalendarDays(year, month);
  }, [year, month]);
  
  const generateCalendarDays = (year: number, month: number) => {
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    
    // Get the day of the week for the first day (0 = Sunday, 6 = Saturday)
    const firstDayOfWeek = firstDayOfMonth.getDay();
    
    // Get days from previous month to fill the first row
    const daysFromPrevMonth = firstDayOfWeek;
    const prevMonth = month === 0 ? 11 : month - 1;
    const prevMonthYear = month === 0 ? year - 1 : year;
    const lastDayOfPrevMonth = new Date(prevMonthYear, prevMonth + 1, 0);
    const daysInPrevMonth = lastDayOfPrevMonth.getDate();
    
    // Get days for next month to fill the last row
    const lastDayOfWeek = lastDayOfMonth.getDay();
    const daysFromNextMonth = 6 - lastDayOfWeek;
    
    const days = [];
    
    // Add days from previous month
    for (let i = daysFromPrevMonth - 1; i >= 0; i--) {
      const dayNumber = daysInPrevMonth - i;
      days.push({ 
        date: new Date(prevMonthYear, prevMonth, dayNumber),
        day: dayNumber, 
        isCurrentMonth: false 
      });
    }
    
    // Add days from current month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({ 
        date: new Date(year, month, i),
        day: i, 
        isCurrentMonth: true 
      });
    }
    
    // Add days from next month
    const nextMonth = month === 11 ? 0 : month + 1;
    const nextMonthYear = month === 11 ? year + 1 : year;
    
    for (let i = 1; i <= daysFromNextMonth; i++) {
      days.push({ 
        date: new Date(nextMonthYear, nextMonth, i),
        day: i, 
        isCurrentMonth: false 
      });
    }
    
    setCalendarDays(days);
  };
  
  const goToPreviousMonth = () => {
    if (month === 0) {
      onMonthChange(11);
    } else {
      onMonthChange(month - 1);
    }
  };
  
  const goToNextMonth = () => {
    if (month === 11) {
      onMonthChange(0);
    } else {
      onMonthChange(month + 1);
    }
  };
  
  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear();
  };
  
  return (
    <div className="bg-white rounded-lg rn-shadow p-4 mb-6">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-bold">{formatMonth(month)} {year}</h3>
        <div className="flex space-x-1">
          <button className="rn-pressable p-1" onClick={goToPreviousMonth}>
            <span className="material-icons text-neutral-400">chevron_left</span>
          </button>
          <button className="rn-pressable p-1" onClick={goToNextMonth}>
            <span className="material-icons text-neutral-400">chevron_right</span>
          </button>
        </div>
      </div>
      
      {/* Days of week */}
      <div className="grid grid-cols-7 mb-2">
        <div className="text-center text-sm font-medium text-neutral-400">Sun</div>
        <div className="text-center text-sm font-medium text-neutral-400">Mon</div>
        <div className="text-center text-sm font-medium text-neutral-400">Tue</div>
        <div className="text-center text-sm font-medium text-neutral-400">Wed</div>
        <div className="text-center text-sm font-medium text-neutral-400">Thu</div>
        <div className="text-center text-sm font-medium text-neutral-400">Fri</div>
        <div className="text-center text-sm font-medium text-neutral-400">Sat</div>
      </div>
      
      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1">
        {calendarDays.map((calDay, index) => {
          const dayHolidays = calDay.date ? getHolidaysForDate(holidays, calDay.date) : [];
          const isCurrentDay = calDay.date ? isToday(calDay.date) : false;
          
          return (
            <div 
              key={index}
              className={`calendar-day p-1 rounded-md relative overflow-hidden ${
                !calDay.isCurrentMonth ? 'text-neutral-300 bg-neutral-100' : ''
              } ${isCurrentDay ? 'today' : ''}`}
            >
              <span className="text-xs font-medium z-10 relative">{calDay.day}</span>
              
              {dayHolidays.length > 0 && (
                <div className="absolute bottom-0 left-0 right-0 px-1 py-0.5 flex flex-col gap-0.5">
                  {dayHolidays.map((holiday, i) => (
                    <div 
                      key={i}
                      className={`h-1.5 rounded-full ${
                        holiday.type === 'NATIONAL' ? 'bg-[hsl(var(--holiday-national))]' :
                        holiday.type === 'REGIONAL' ? 'bg-[hsl(var(--holiday-regional))]' :
                        'bg-[hsl(var(--holiday-observance))]'
                      }`}
                      title={holiday.name}
                    ></div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {/* Legend */}
      <div className="flex mt-4 pt-4 border-t border-neutral-200 flex-wrap gap-4">
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-[hsl(var(--holiday-national))] mr-2"></div>
          <span className="text-xs font-medium">National Holiday</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-[hsl(var(--holiday-regional))] mr-2"></div>
          <span className="text-xs font-medium">Regional Holiday</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-[hsl(var(--holiday-observance))] mr-2"></div>
          <span className="text-xs font-medium">Observance</span>
        </div>
      </div>
    </div>
  );
}
