import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import YearSelector from "./YearSelector";
import { State, Lob, Loc } from "../lib/types";

interface FilterSectionProps {
  selectedYear: number;
  onYearChange: (year: number) => void;
  selectedState: number;
  onStateChange: (stateId: number) => void;
  workWeek: number;
  onWorkWeekChange: (days: number) => void;
  selectedLobLoc: number;
  onLobLocChange: (id: number) => void;
  viewMode: "calendar" | "list";
  onViewModeChange: (mode: "calendar" | "list") => void;
  onApplyFilters: () => void;
}

export default function FilterSection({
  selectedYear,
  onYearChange,
  selectedState,
  onStateChange,
  workWeek,
  onWorkWeekChange,
  selectedLobLoc,
  onLobLocChange,
  viewMode,
  onViewModeChange,
  onApplyFilters
}: FilterSectionProps) {
  const { data: states } = useQuery<State[]>({
    queryKey: ["/api/states"],
  });

  const { data: lobs } = useQuery<Lob[]>({
    queryKey: ["/api/lobs"],
  });

  return (
    <div className="bg-white rounded-lg rn-shadow p-4 md:p-6 mb-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
        <h2 className="text-xl font-bold text-neutral-500 mb-4 md:mb-0">Holiday Calendar</h2>
        
        <YearSelector 
          selectedYear={selectedYear}
          onYearChange={onYearChange}
        />
      </div>
      
      <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
        {/* State Filter */}
        <div className="flex-1">
          <label className="block text-sm font-medium text-neutral-400 mb-1">State/Region</label>
          <div className="relative">
            <select 
              className="w-full bg-neutral-100 border border-neutral-200 rounded-lg px-4 py-2 appearance-none focus:outline-none focus:ring-2 focus:ring-primary"
              value={selectedState}
              onChange={(e) => onStateChange(Number(e.target.value))}
            >
              {states?.map((state) => (
                <option key={state.id} value={state.id}>{state.name}</option>
              ))}
            </select>
            <span className="material-icons absolute right-3 top-2 text-neutral-300">arrow_drop_down</span>
          </div>
        </div>
        
        {/* Work Week Filter */}
        <div className="flex-1">
          <label className="block text-sm font-medium text-neutral-400 mb-1">Work Week</label>
          <div className="flex bg-neutral-100 rounded-lg p-1">
            <button 
              className={`flex-1 rn-pressable rounded-md py-1 ${workWeek === 5 ? 'bg-primary text-white font-medium' : 'text-neutral-400'}`}
              onClick={() => onWorkWeekChange(5)}
            >
              5-Day
            </button>
            <button 
              className={`flex-1 rn-pressable rounded-md py-1 ${workWeek === 6 ? 'bg-primary text-white font-medium' : 'text-neutral-400'}`}
              onClick={() => onWorkWeekChange(6)}
            >
              6-Day
            </button>
          </div>
        </div>
        
        {/* LOB/LOC Filter */}
        <div className="flex-1">
          <label className="block text-sm font-medium text-neutral-400 mb-1">LOB/LOC</label>
          <div className="relative">
            <select 
              className="w-full bg-neutral-100 border border-neutral-200 rounded-lg px-4 py-2 appearance-none focus:outline-none focus:ring-2 focus:ring-primary"
              value={selectedLobLoc}
              onChange={(e) => onLobLocChange(Number(e.target.value))}
            >
              {lobs?.map((lob) => (
                <option key={lob.id} value={lob.id}>{lob.name}</option>
              ))}
            </select>
            <span className="material-icons absolute right-3 top-2 text-neutral-300">arrow_drop_down</span>
          </div>
        </div>
      </div>
      
      {/* Show Holidays Button and View Toggle */}
      <div className="flex flex-col md:flex-row justify-between items-center mt-4">
        <button 
          className="w-full md:w-auto mb-3 md:mb-0 py-2 px-6 bg-primary text-white font-medium rounded-lg rn-pressable flex items-center justify-center"
          onClick={onApplyFilters}
        >
          <span className="material-icons text-sm mr-1">search</span>
          <span>Show Holidays</span>
        </button>
        
        <div className="flex bg-neutral-100 rounded-lg p-1 w-full md:w-auto">
          <button 
            className={`rn-pressable rounded-md py-1 px-3 flex items-center font-medium flex-1 md:flex-auto ${viewMode === 'calendar' ? 'bg-primary text-white' : 'text-neutral-400'}`}
            onClick={() => onViewModeChange("calendar")}
          >
            <span className="material-icons text-sm mr-1">calendar_month</span>
            <span>Calendar</span>
          </button>
          <button 
            className={`rn-pressable rounded-md py-1 px-3 flex items-center flex-1 md:flex-auto ${viewMode === 'list' ? 'bg-primary text-white' : 'text-neutral-400'}`}
            onClick={() => onViewModeChange("list")}
          >
            <span className="material-icons text-sm mr-1">list</span>
            <span>List</span>
          </button>
        </div>
      </div>
    </div>
  );
}
