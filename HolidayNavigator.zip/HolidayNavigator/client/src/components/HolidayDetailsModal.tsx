import { Holiday } from "../lib/types";
import { formatDate, getWeekday } from "../lib/utils";

interface HolidayDetailsModalProps {
  holiday: Holiday;
  isOpen: boolean;
  onClose: () => void;
}

export default function HolidayDetailsModal({ 
  holiday, 
  isOpen, 
  onClose 
}: HolidayDetailsModalProps) {
  if (!isOpen) return null;
  
  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    onClose();
  };
  
  const handleModalClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
  };
  
  const handleDownload = () => {
    // In a real app, this would generate and download a file
    // For now, we'll just show an alert
    alert(`Downloaded details for ${holiday.name}`);
  };
  
  const holidayDate = new Date(holiday.date);
  const weekday = getWeekday(holidayDate);
  
  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 fade-in z-50"
      onClick={handleBackdropClick}
    >
      <div 
        className="bg-white rounded-lg w-full max-w-md p-6"
        onClick={handleModalClick}
      >
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-lg font-bold">{holiday.name}</h3>
          <button className="rn-pressable" onClick={onClose}>
            <span className="material-icons">close</span>
          </button>
        </div>
        
        <div className="space-y-4">
          <div>
            <p className="text-sm text-neutral-300 mb-1">Date</p>
            <p className="font-medium">{formatDate(holiday.date)} ({weekday})</p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-300 mb-1">Type</p>
            <p className={`inline-block px-2 py-1 rounded-full text-xs bg-neutral-100 ${
              holiday.type === 'NATIONAL' ? 'text-[hsl(var(--holiday-national))]' :
              holiday.type === 'REGIONAL' ? 'text-[hsl(var(--holiday-regional))]' :
              'text-[hsl(var(--holiday-observance))]'
            } font-medium`}>
              {holiday.type === 'NATIONAL' ? 'National Holiday' :
               holiday.type === 'REGIONAL' ? 'Regional Holiday' :
               'Observance'}
            </p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-300 mb-1">Applicable for</p>
            <p>{holiday.type === 'NATIONAL' ? 'All States' : 'Maharashtra'}</p>
          </div>
          
          {holiday.description && (
            <div>
              <p className="text-sm text-neutral-300 mb-1">Description</p>
              <p className="text-sm">{holiday.description}</p>
            </div>
          )}
        </div>
        
        <div className="mt-6 pt-4 border-t border-neutral-200 flex">
          <button 
            className="flex-1 py-2 mr-2 text-center rounded-lg bg-neutral-100 text-neutral-400 rn-pressable"
            onClick={onClose}
          >
            Close
          </button>
          <button 
            className="flex-1 py-2 ml-2 text-center rounded-lg bg-primary text-white rn-pressable"
            onClick={handleDownload}
          >
            Download
          </button>
        </div>
      </div>
    </div>
  );
}
