import { useState } from "react";
import { Holiday } from "../lib/types";
import { formatDate } from "../lib/utils";
import HolidayDetailsModal from "./HolidayDetailsModal";

interface HolidaysListProps {
  holidays: Holiday[];
}

export default function HolidaysList({ holidays }: HolidaysListProps) {
  const [selectedHoliday, setSelectedHoliday] = useState<Holiday | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const handleHolidayClick = (holiday: Holiday) => {
    setSelectedHoliday(holiday);
    setIsModalOpen(true);
  };
  
  const closeModal = () => {
    setIsModalOpen(false);
  };
  
  // Filter to show only upcoming holidays
  const today = new Date();
  const upcomingHolidays = holidays
    .filter(holiday => new Date(holiday.date) >= today)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 3); // Show only 3 upcoming holidays
  
  const allHolidays = [...holidays].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  const [showAllHolidays, setShowAllHolidays] = useState(false);
  
  return (
    <>
      <div className="bg-white rounded-lg rn-shadow p-4">
        <h3 className="text-lg font-bold mb-4">
          {showAllHolidays ? "All Holidays" : "Upcoming Holidays"}
        </h3>
        
        <div className="space-y-3">
          {(showAllHolidays ? allHolidays : upcomingHolidays).map((holiday) => (
            <div 
              key={holiday.id}
              className={`border-l-4 ${
                holiday.type === 'NATIONAL' ? 'border-[hsl(var(--holiday-national))]' :
                holiday.type === 'REGIONAL' ? 'border-[hsl(var(--holiday-regional))]' :
                'border-[hsl(var(--holiday-observance))]'
              } bg-neutral-100 rounded-r-lg p-3 cursor-pointer hover:bg-neutral-50 transition-colors`}
              onClick={() => handleHolidayClick(holiday)}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-medium">{holiday.name}</h4>
                  <p className="text-xs text-neutral-400">{formatDate(holiday.date)}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs bg-white ${
                  holiday.type === 'NATIONAL' ? 'text-[hsl(var(--holiday-national))]' :
                  holiday.type === 'REGIONAL' ? 'text-[hsl(var(--holiday-regional))]' :
                  'text-[hsl(var(--holiday-observance))]'
                } font-medium`}>
                  {holiday.type === 'NATIONAL' ? 'National' :
                   holiday.type === 'REGIONAL' ? 'Regional' :
                   'Observance'}
                </span>
              </div>
              {holiday.type === 'REGIONAL' && (
                <p className="text-xs text-neutral-400 mt-1">Applicable for: Maharashtra</p>
              )}
            </div>
          ))}
          
          {upcomingHolidays.length === 0 && !showAllHolidays && (
            <div className="text-center py-4 text-neutral-400">
              No upcoming holidays found
            </div>
          )}
          
          {allHolidays.length === 0 && showAllHolidays && (
            <div className="text-center py-4 text-neutral-400">
              No holidays found
            </div>
          )}
        </div>
        
        <button 
          className="mt-4 w-full py-2 text-center text-primary font-medium border border-primary rounded-lg rn-pressable"
          onClick={() => setShowAllHolidays(!showAllHolidays)}
        >
          {showAllHolidays ? "Show Upcoming Holidays" : "View All Holidays"}
        </button>
      </div>
      
      {selectedHoliday && (
        <HolidayDetailsModal 
          holiday={selectedHoliday} 
          isOpen={isModalOpen} 
          onClose={closeModal} 
        />
      )}
    </>
  );
}
