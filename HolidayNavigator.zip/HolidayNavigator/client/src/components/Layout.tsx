import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import BottomTabs from "./BottomTabs";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="flex flex-col min-h-screen md:flex-row">
      <Sidebar />
      <main className="flex-1 flex flex-col">
        <TopBar />
        {children}
        <BottomTabs />
      </main>
    </div>
  );
}
