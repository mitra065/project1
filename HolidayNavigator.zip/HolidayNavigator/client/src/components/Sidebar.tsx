import { useLocation, Link } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="hidden md:flex md:flex-col md:w-64 bg-white border-r border-neutral-200 p-4 h-screen">
      <div className="flex items-center mb-8">
        <span className="material-icons text-primary text-3xl mr-2">event</span>
        <h1 className="text-xl font-bold text-primary">Holiday Manager</h1>
      </div>
      
      <nav className="space-y-1">
        <Link href="/">
          <div className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location === '/' ? 'text-primary bg-blue-50' : 'text-neutral-400 hover:bg-neutral-100'}`}>
            <span className="material-icons mr-3">calendar_today</span>
            <span>Holidays</span>
          </div>
        </Link>
        <Link href="/settings">
          <div className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location === '/settings' ? 'text-primary bg-blue-50' : 'text-neutral-400 hover:bg-neutral-100'}`}>
            <span className="material-icons mr-3">settings</span>
            <span>Settings</span>
          </div>
        </Link>
        <Link href="/help">
          <div className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location === '/help' ? 'text-primary bg-blue-50' : 'text-neutral-400 hover:bg-neutral-100'}`}>
            <span className="material-icons mr-3">help_outline</span>
            <span>Help</span>
          </div>
        </Link>
        <Link href="/admin">
          <div className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location === '/admin' ? 'text-primary bg-blue-50' : 'text-neutral-400 hover:bg-neutral-100'}`}>
            <span className="material-icons mr-3">admin_panel_settings</span>
            <span>Admin</span>
          </div>
        </Link>
        <Link href="/admin-paper">
          <div className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location === '/admin-paper' ? 'text-primary bg-blue-50' : 'text-neutral-400 hover:bg-neutral-100'}`}>
            <span className="material-icons mr-3">description</span>
            <span>Admin (Paper UI)</span>
          </div>
        </Link>
      </nav>
      
      <div className="mt-auto pt-6 border-t border-neutral-200">
        <div className="flex items-center px-4 py-3">
          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium">
            JD
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">User</p>
            <p className="text-xs text-neutral-300">user@example.com</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
