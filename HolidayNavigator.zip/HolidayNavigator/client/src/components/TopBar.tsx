import { useState } from "react";

export default function TopBar() {
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);

  const toggleProfileMenu = () => {
    setProfileMenuOpen(!profileMenuOpen);
  };

  return (
    <header className="md:hidden bg-primary text-white p-4 flex items-center justify-between">
      <div className="flex items-center">
        <span className="material-icons mr-2">event</span>
        <h1 className="text-lg font-medium">Holiday Manager</h1>
      </div>
      <button className="rn-pressable" onClick={toggleProfileMenu}>
        <span className="material-icons">account_circle</span>
      </button>
      
      {profileMenuOpen && (
        <div className="absolute right-4 top-16 bg-white shadow-lg rounded-lg p-4 z-50">
          <div className="flex items-center mb-3">
            <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium">
              JD
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-neutral-500">User</p>
              <p className="text-xs text-neutral-300">user@example.com</p>
            </div>
          </div>
          <hr className="my-2" />
          <button onClick={toggleProfileMenu} className="w-full text-left py-2 text-neutral-500 text-sm">
            Sign Out
          </button>
        </div>
      )}
    </header>
  );
}
