interface YearSelectorProps {
  selectedYear: number;
  onYearChange: (year: number) => void;
}

export default function YearSelector({ selectedYear, onYearChange }: YearSelectorProps) {
  // Generate a range of years from 5 years ago to 5 years in the future
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 11 }, (_, i) => currentYear - 5 + i);
  
  const goToPreviousYear = () => {
    onYearChange(selectedYear - 1);
  };
  
  const goToNextYear = () => {
    onYearChange(selectedYear + 1);
  };
  
  return (
    <div className="bg-neutral-100 rounded-lg p-1 flex items-center">
      <button className="rn-pressable p-1" onClick={goToPreviousYear}>
        <span className="material-icons text-neutral-400">chevron_left</span>
      </button>
      
      <div className="px-2 overflow-x-auto custom-scrollbar flex space-x-1 whitespace-nowrap">
        {years.map(year => (
          <button 
            key={year}
            className={`year-item px-3 py-1 rounded-md rn-pressable ${year === selectedYear ? 'active' : ''}`}
            onClick={() => onYearChange(year)}
          >
            {year}
          </button>
        ))}
      </div>
      
      <button className="rn-pressable p-1" onClick={goToNextYear}>
        <span className="material-icons text-neutral-400">chevron_right</span>
      </button>
    </div>
  );
}
