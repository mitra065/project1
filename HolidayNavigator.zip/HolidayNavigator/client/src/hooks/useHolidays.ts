import { useQuery } from "@tanstack/react-query";
import { Holiday, FilterOptions } from "../lib/types";

export default function useHolidays(filters: FilterOptions = {}) {
  const { year, stateId, lobId, locId } = filters;
  
  const queryParams: Record<string, string | number> = {};
  
  if (year) queryParams.year = year;
  if (stateId) queryParams.stateId = stateId;
  if (lobId) queryParams.lobId = lobId;
  if (locId) queryParams.locId = locId;
  
  return useQuery<Holiday[]>({
    queryKey: ["/api/holidays", queryParams],
  });
}
