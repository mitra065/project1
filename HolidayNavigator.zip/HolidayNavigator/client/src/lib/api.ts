import axios from "axios";
import { Holiday, State, Lob, Loc } from "./types";

// Create axios instance
const api = axios.create({
  baseURL: "/api",
  headers: {
    "Content-Type": "application/json",
  },
});

// API functions
export const fetchHolidays = async (params?: { year?: number; stateId?: number; lobId?: number; locId?: number }) => {
  const response = await api.get<Holiday[]>("/holidays", { params });
  return response.data;
};

export const fetchHolidayById = async (id: number) => {
  const response = await api.get<Holiday>(`/holidays/${id}`);
  return response.data;
};

export const fetchStates = async () => {
  const response = await api.get<State[]>("/states");
  return response.data;
};

export const fetchLobs = async () => {
  const response = await api.get<Lob[]>("/lobs");
  return response.data;
};

export const fetchLocs = async () => {
  const response = await api.get<Loc[]>("/locs");
  return response.data;
};

export const fetchHolidayStates = async (holidayId: number) => {
  const response = await api.get<State[]>(`/holidays/${holidayId}/states`);
  return response.data;
};

export default api;
