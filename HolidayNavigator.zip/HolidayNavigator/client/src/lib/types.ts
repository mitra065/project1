// Holiday types
export type HolidayType = "NATIONAL" | "REGIONAL" | "OBSERVANCE";

// Holiday interface
export interface Holiday {
  id: number;
  name: string;
  date: Date | string;
  description?: string;
  type: HolidayType;
}

// State interface
export interface State {
  id: number;
  name: string;
  code: string;
}

// LOB (Line of Business) interface
export interface Lob {
  id: number;
  name: string;
  code: string;
}

// LOC (Location) interface
export interface Loc {
  id: number;
  name: string;
  code: string;
}

// Holiday-State association
export interface HolidayState {
  id: number;
  holidayId: number;
  stateId: number;
}

// Holiday-LOB association
export interface HolidayLob {
  id: number;
  holidayId: number;
  lobId: number;
}

// Holiday-LOC association
export interface HolidayLoc {
  id: number;
  holidayId: number;
  locId: number;
}

// Filter options
export interface FilterOptions {
  year?: number;
  stateId?: number;
  workWeek?: 5 | 6;
  lobId?: number;
  locId?: number;
}

// View mode
export type ViewMode = "calendar" | "list";
