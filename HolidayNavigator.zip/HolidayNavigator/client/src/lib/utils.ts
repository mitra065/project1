import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Holiday } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format a date to a readable string (e.g., "January 1, 2023")
export function formatDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });
}

// Get the weekday of a date (e.g., "Monday")
export function getWeekday(date: Date): string {
  return date.toLocaleDateString('en-US', { weekday: 'long' });
}

// Format month name (e.g., "January")
export function formatMonth(month: number): string {
  const date = new Date();
  date.setMonth(month);
  return date.toLocaleDateString('en-US', { month: 'long' });
}

// Get all holidays for a specific date
export function getHolidaysForDate(holidays: Holiday[], date: Date): Holiday[] {
  return holidays.filter(holiday => {
    const holidayDate = new Date(holiday.date);
    return holidayDate.getDate() === date.getDate() &&
           holidayDate.getMonth() === date.getMonth() &&
           holidayDate.getFullYear() === date.getFullYear();
  });
}

// Check if a date is a weekend (Saturday or Sunday)
export function isWeekend(date: Date): boolean {
  const day = date.getDay();
  return day === 0 || day === 6; // 0 is Sunday, 6 is Saturday
}

// Check if a date is within a 5-day work week (Monday to Friday)
export function isWorkDay5(date: Date): boolean {
  const day = date.getDay();
  return day >= 1 && day <= 5;
}

// Check if a date is within a 6-day work week (Monday to Saturday)
export function isWorkDay6(date: Date): boolean {
  const day = date.getDay();
  return day >= 1 && day <= 6;
}

// Generate an array of years around the current year
export function getYearRange(currentYear: number, range: number = 5): number[] {
  const years = [];
  for (let i = currentYear - range; i <= currentYear + range; i++) {
    years.push(i);
  }
  return years;
}
