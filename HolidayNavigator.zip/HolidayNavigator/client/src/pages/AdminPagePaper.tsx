import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Paper, Typography, TextField, Button, FormControl, InputLabel, MenuItem, Select, Stack, Box } from "@mui/material";
import { Add as AddIcon } from "@mui/icons-material";
import { queryClient } from "../lib/queryClient";
import { Lob, Loc, HolidayType, Holiday } from "../lib/types";
import { useToast } from "@/hooks/use-toast";

export default function AdminPagePaper() {
  const { toast } = useToast();
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);
  
  // Format the date to YYYY-MM-DD for the date input
  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0];
  };
  
  // Form state
  const [selectedDate, setSelectedDate] = useState<string>(formatDateForInput(tomorrow));
  const [holidayName, setHolidayName] = useState("");
  const [holidayDescription, setHolidayDescription] = useState("");
  const [holidayType, setHolidayType] = useState<HolidayType>("NATIONAL");
  const [selectedLob, setSelectedLob] = useState<string>("0");
  const [selectedLoc, setSelectedLoc] = useState<string>("0");
  
  // Fetch LOBs and LOCs
  const { data: lobs = [] } = useQuery<Lob[]>({
    queryKey: ["/api/lobs"],
  });
  
  const { data: locs = [] } = useQuery<Loc[]>({
    queryKey: ["/api/locs"],
  });
  
  // Create holiday mutation
  const createHolidayMutation = useMutation({
    mutationFn: async (newHoliday: any) => {
      const response = await fetch("/api/holidays", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newHoliday),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create holiday");
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Reset form
      setSelectedDate(formatDateForInput(tomorrow));
      setHolidayName("");
      setHolidayDescription("");
      setHolidayType("NATIONAL");
      setSelectedLob("0");
      setSelectedLoc("0");
      
      // Invalidate holiday queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/holidays"] });
      
      // Show success message
      toast({
        title: "Holiday Created",
        description: "The holiday has been successfully added to the calendar.",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Holiday",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDate) {
      toast({
        title: "Date Required",
        description: "Please select a date for the holiday.",
        variant: "destructive",
      });
      return;
    }
    
    if (!holidayName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a name for the holiday.",
        variant: "destructive",
      });
      return;
    }
    
    // Check if date is in the future
    const dateObject = new Date(selectedDate);
    if (dateObject < today) {
      toast({
        title: "Invalid Date",
        description: "Please select a future date for the holiday.",
        variant: "destructive",
      });
      return;
    }
    
    const newHoliday = {
      name: holidayName,
      date: dateObject,
      description: holidayDescription || undefined,
      type: holidayType,
      lobId: selectedLob !== "0" ? Number(selectedLob) : null,
      locId: selectedLoc !== "0" ? Number(selectedLoc) : null
    };
    
    createHolidayMutation.mutate(newHoliday);
  };
  
  return (
    <Box className="flex-1 overflow-y-auto p-4 md:p-6">
      <Typography variant="h4" gutterBottom>
        Holiday Administration (Paper UI)
      </Typography>
      
      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Typography variant="h5" gutterBottom>
          Add New Holiday
        </Typography>
        <Typography variant="body2" color="text.secondary" paragraph>
          Create a new holiday by selecting a future date and filling out the details below.
        </Typography>
        
        <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Stack spacing={3}>
            {/* Date Input */}
            <TextField
              label="Holiday Date (Future dates only)"
              type="date"
              fullWidth
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              inputProps={{ min: formatDateForInput(today) }}
              required
            />
            
            {/* Holiday Name */}
            <TextField
              label="Holiday Name"
              fullWidth
              value={holidayName}
              onChange={(e) => setHolidayName(e.target.value)}
              required
              placeholder="e.g., New Year's Day"
            />
            
            {/* Holiday Description */}
            <TextField
              label="Description (Optional)"
              fullWidth
              multiline
              rows={3}
              value={holidayDescription}
              onChange={(e) => setHolidayDescription(e.target.value)}
              placeholder="Enter a description of the holiday..."
            />
            
            {/* Holiday Type */}
            <FormControl fullWidth>
              <InputLabel>Holiday Type</InputLabel>
              <Select
                value={holidayType}
                label="Holiday Type"
                onChange={(e) => setHolidayType(e.target.value as HolidayType)}
              >
                <MenuItem value="NATIONAL">National Holiday</MenuItem>
                <MenuItem value="REGIONAL">Regional Holiday</MenuItem>
                <MenuItem value="OBSERVANCE">Observance</MenuItem>
              </Select>
            </FormControl>
            
            {/* LOB Selection */}
            <FormControl fullWidth>
              <InputLabel>Line of Business (Optional)</InputLabel>
              <Select
                value={selectedLob}
                label="Line of Business (Optional)"
                onChange={(e) => setSelectedLob(e.target.value)}
              >
                <MenuItem value="0">None (All LOBs)</MenuItem>
                {lobs.map((lob) => (
                  <MenuItem key={lob.id} value={lob.id.toString()}>
                    {lob.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            {/* LOC Selection */}
            <FormControl fullWidth>
              <InputLabel>Location (Optional)</InputLabel>
              <Select
                value={selectedLoc}
                label="Location (Optional)"
                onChange={(e) => setSelectedLoc(e.target.value)}
              >
                <MenuItem value="0">None (All Locations)</MenuItem>
                {locs.map((loc) => (
                  <MenuItem key={loc.id} value={loc.id.toString()}>
                    {loc.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            {/* Submit Button */}
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              size="large"
              disabled={createHolidayMutation.isPending}
              startIcon={<AddIcon />}
            >
              {createHolidayMutation.isPending ? "Processing..." : "Add Holiday"}
            </Button>
          </Stack>
        </Box>
      </Paper>
    </Box>
  );
}