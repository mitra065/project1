import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Help() {
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6">
      <h1 className="text-2xl font-bold mb-6">Help Center</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>How to Use the Holiday Manager</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            The Holiday Manager helps you track and manage holidays across different states and
            regions. This guide will help you understand how to use the application effectively.
          </p>
        </CardContent>
      </Card>
      
      <Accordion type="single" collapsible className="bg-white rounded-lg">
        <AccordionItem value="item-1">
          <AccordionTrigger className="px-4 py-3 hover:bg-neutral-50">
            How do I filter holidays by state?
          </AccordionTrigger>
          <AccordionContent className="px-4 py-2 text-neutral-400">
            You can filter holidays by state using the State/Region dropdown in the filter section.
            Select the state you want to view holidays for, and the calendar and list will update
            to show only holidays applicable to that state.
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-2">
          <AccordionTrigger className="px-4 py-3 hover:bg-neutral-50">
            What do the different holiday colors mean?
          </AccordionTrigger>
          <AccordionContent className="px-4 py-2 text-neutral-400">
            <p>Holidays are color-coded based on their type:</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Green: National holidays applicable to all states</li>
              <li>Orange: Regional holidays specific to certain states</li>
              <li>Red: Observances and other special days</li>
            </ul>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-3">
          <AccordionTrigger className="px-4 py-3 hover:bg-neutral-50">
            What is the difference between 5-day and 6-day work week?
          </AccordionTrigger>
          <AccordionContent className="px-4 py-2 text-neutral-400">
            <p>The work week setting affects how holidays are calculated:</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>5-day work week: Monday through Friday are considered working days</li>
              <li>6-day work week: Monday through Saturday are considered working days</li>
            </ul>
            <p className="mt-2">
              This setting is especially important for determining leave calculations and 
              compensatory holidays when a holiday falls on a weekend.
            </p>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-4">
          <AccordionTrigger className="px-4 py-3 hover:bg-neutral-50">
            What is LOB/LOC and how does it affect holidays?
          </AccordionTrigger>
          <AccordionContent className="px-4 py-2 text-neutral-400">
            LOB (Line of Business) and LOC (Location) are categories that may have specific
            holiday policies. Some businesses or locations might observe additional holidays
            based on local customs or business requirements. This filter allows you to see
            holidays specific to your business unit or location.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
