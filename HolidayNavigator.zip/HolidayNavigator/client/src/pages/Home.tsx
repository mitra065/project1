import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import FilterSection from "../components/FilterSection";
import CalendarView from "../components/CalendarView";
import HolidaysList from "../components/HolidaysList";
import { Holiday } from "../lib/types";
import { useLocation } from "wouter";

export default function Home() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split('?')[1] || '');
  
  // Default view based on URL parameters
  const defaultView = params.get('view') === 'list' ? 'list' : 'calendar';
  
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth();
  
  // Filter state
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedState, setSelectedState] = useState(1); // Default to "All States"
  const [workWeek, setWorkWeek] = useState(5); // Default to 5-day work week
  const [selectedLobLoc, setSelectedLobLoc] = useState(1); // Default to "All Categories"
  const [viewMode, setViewMode] = useState<"calendar" | "list">(defaultView);
  
  // Applied filter state
  const [appliedFilters, setAppliedFilters] = useState({
    year: currentYear,
    stateId: 1,
    lobId: 1
  });
  
  // Control display state
  const [showContent, setShowContent] = useState(false);
  
  // Fetch holidays based on applied filters
  const { data: holidays = [], refetch } = useQuery<Holiday[]>({
    queryKey: ["/api/holidays", appliedFilters],
    enabled: showContent, // Only fetch when filters are applied
  });
  
  // Handle filter application
  const handleApplyFilters = () => {
    setAppliedFilters({
      year: selectedYear,
      stateId: selectedState,
      lobId: selectedLobLoc
    });
    setShowContent(true);
    refetch(); // Ensure data is fetched after filter changes
  };
  
  // Apply filters on initial load
  useEffect(() => {
    handleApplyFilters();
  }, []);
  
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6">
      <FilterSection 
        selectedYear={selectedYear}
        onYearChange={setSelectedYear}
        selectedState={selectedState}
        onStateChange={setSelectedState}
        workWeek={workWeek}
        onWorkWeekChange={setWorkWeek}
        selectedLobLoc={selectedLobLoc}
        onLobLocChange={setSelectedLobLoc}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onApplyFilters={handleApplyFilters}
      />
      
      {showContent && (
        <>
          {viewMode === "calendar" && (
            <CalendarView 
              holidays={holidays}
              year={appliedFilters.year}
              month={selectedMonth}
              onMonthChange={setSelectedMonth}
            />
          )}
          
          <HolidaysList holidays={holidays} />
        </>
      )}
      
      {!showContent && (
        <div className="bg-white rounded-lg rn-shadow p-6 text-center">
          <p className="text-neutral-400">Please apply filters to see holidays</p>
        </div>
      )}
    </div>
  );
}
