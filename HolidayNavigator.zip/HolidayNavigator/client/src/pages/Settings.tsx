import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function Settings() {
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Configure how you want to be notified about holidays</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="email-notifications" className="font-medium">Email Notifications</Label>
                <p className="text-sm text-neutral-300">Receive holiday reminders via email</p>
              </div>
              <Switch id="email-notifications" />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="upcoming-reminders" className="font-medium">Upcoming Holiday Reminders</Label>
                <p className="text-sm text-neutral-300">Get reminded 3 days before holidays</p>
              </div>
              <Switch id="upcoming-reminders" defaultChecked />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Display Preferences</CardTitle>
            <CardDescription>Customize how holidays are displayed</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="weekend-display" className="font-medium">Show Weekends</Label>
                <p className="text-sm text-neutral-300">Display weekend days in calendar</p>
              </div>
              <Switch id="weekend-display" defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="past-holidays" className="font-medium">Show Past Holidays</Label>
                <p className="text-sm text-neutral-300">Include holidays that have already occurred</p>
              </div>
              <Switch id="past-holidays" defaultChecked />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
