// Holiday Types
export type HolidayType = "NATIONAL" | "REGIONAL" | "OBSERVANCE";

export interface Holiday {
  id: number;
  name: string;
  date: Date | string;
  description?: string;
  type: HolidayType;
}

export interface State {
  id: number;
  name: string;
  code: string;
}

export interface Lob {
  id: number;
  name: string;
  code: string;
}

export interface Loc {
  id: number;
  name: string;
  code: string;
}

export interface HolidayState {
  id: number;
  holidayId: number;
  stateId: number;
}

export interface HolidayLob {
  id: number;
  holidayId: number;
  lobId: number;
}

export interface HolidayLoc {
  id: number;
  holidayId: number;
  locId: number;
}

export interface FilterOptions {
  year?: number;
  stateId?: number;
  workWeek?: 5 | 6;
  lobId?: number;
  locId?: number;
}

export type ViewMode = "calendar" | "list";

// Navigation Types
export type RootStackParamList = {
  Main: undefined;
};

export type TabParamList = {
  Calendar: undefined;
  List: undefined;
  Filter: undefined;
  Settings: undefined;
  Admin: undefined;
  AdminPaper: undefined;
};