import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the application
  
  // GET /api/states - Get all states
  app.get("/api/states", async (req, res) => {
    try {
      const states = await storage.getStates();
      res.json(states);
    } catch (error) {
      res.status(500).json({ message: "Error fetching states" });
    }
  });
  
  // GET /api/lobs - Get all LOBs
  app.get("/api/lobs", async (req, res) => {
    try {
      const lobs = await storage.getLobs();
      res.json(lobs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching LOBs" });
    }
  });
  
  // GET /api/locs - Get all LOCs
  app.get("/api/locs", async (req, res) => {
    try {
      const locs = await storage.getLocs();
      res.json(locs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching LOCs" });
    }
  });
  
  // GET /api/holidays - Get all holidays
  app.get("/api/holidays", async (req, res) => {
    try {
      const { year, stateId, lobId, locId } = req.query;
      
      let holidays;
      
      // Filter by year and state if provided
      if (year && stateId) {
        holidays = await storage.getHolidaysByYearAndState(
          parseInt(year as string), 
          parseInt(stateId as string)
        );
      } 
      // Filter by year only
      else if (year) {
        holidays = await storage.getHolidaysByYear(parseInt(year as string));
      } 
      // Filter by state only
      else if (stateId) {
        holidays = await storage.getHolidaysByState(parseInt(stateId as string));
      } 
      // Filter by LOB
      else if (lobId) {
        holidays = await storage.getHolidaysByLob(parseInt(lobId as string));
      } 
      // Filter by LOC
      else if (locId) {
        holidays = await storage.getHolidaysByLoc(parseInt(locId as string));
      } 
      // Get all holidays
      else {
        holidays = await storage.getHolidays();
      }

      // Sort holidays by date
      holidays.sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateA.getTime() - dateB.getTime();
      });
      
      res.json(holidays);
    } catch (error) {
      res.status(500).json({ message: "Error fetching holidays" });
    }
  });
  
  // GET /api/holidays/:id - Get a specific holiday
  app.get("/api/holidays/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const holiday = await storage.getHoliday(parseInt(id));
      
      if (!holiday) {
        return res.status(404).json({ message: "Holiday not found" });
      }
      
      res.json(holiday);
    } catch (error) {
      res.status(500).json({ message: "Error fetching holiday" });
    }
  });
  
  // GET /api/holidays/:id/states - Get states for a specific holiday
  app.get("/api/holidays/:id/states", async (req, res) => {
    try {
      const { id } = req.params;
      const holiday = await storage.getHoliday(parseInt(id));
      
      if (!holiday) {
        return res.status(404).json({ message: "Holiday not found" });
      }
      
      // For a real database, we would join the tables
      // Since we're using in-memory storage, we'll simulate the join
      const allHolidayStates = Array.from((await storage as any).holidayStates.values());
      const holidayStates = allHolidayStates.filter((hs: any) => hs.holidayId === parseInt(id));
      
      const stateIds = holidayStates.map((hs: any) => hs.stateId);
      const states = await Promise.all(stateIds.map(sid => storage.getState(sid)));
      
      res.json(states.filter(s => s !== undefined));
    } catch (error) {
      res.status(500).json({ message: "Error fetching states for holiday" });
    }
  });
  
  // POST /api/holidays - Create a new holiday
  app.post("/api/holidays", async (req, res) => {
    try {
      const { name, date, description, type, lobId, locId } = req.body;
      
      // Basic validation
      if (!name || !date || !type) {
        return res.status(400).json({ message: "Name, date, and type are required" });
      }
      
      // Validate date is in the future
      const holidayDate = new Date(date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (holidayDate < today) {
        return res.status(400).json({ message: "Holiday date must be in the future" });
      }
      
      // Create the holiday
      const newHoliday = await storage.createHoliday({
        name,
        date: holidayDate.toISOString(),
        description,
        type
      });
      
      // If it's a regional holiday, associate it with the specified state
      // In a real app, you would get this from the request
      if (type === "REGIONAL") {
        // We're using a default state ID of 2 (Maharashtra) for this example
        await storage.addHolidayState({
          holidayId: newHoliday.id,
          stateId: 2 // Default to Maharashtra for regional holidays
        });
      }
      
      // Associate with LOB if provided
      if (lobId) {
        await storage.addHolidayLob({
          holidayId: newHoliday.id,
          lobId
        });
      }
      
      // Associate with LOC if provided
      if (locId) {
        await storage.addHolidayLoc({
          holidayId: newHoliday.id,
          locId
        });
      }
      
      res.status(201).json(newHoliday);
    } catch (error) {
      console.error("Error creating holiday:", error);
      res.status(500).json({ message: "Error creating holiday" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
