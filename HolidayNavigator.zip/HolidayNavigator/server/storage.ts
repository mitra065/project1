import { 
  users, type User, type InsertUser,
  states, type State, type InsertState,
  lobs, type Lob, type InsertLob,
  locs, type Loc, type InsertLoc,
  holidays, type Holiday, type InsertHoliday,
  holidayStates, type HolidayState, type InsertHolidayState,
  holidayLobs, type HolidayLob, type InsertHolidayLob,
  holidayLocs, type HolidayLoc, type InsertHolidayLoc,
  HolidayType
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // State methods
  getStates(): Promise<State[]>;
  getState(id: number): Promise<State | undefined>;
  createState(state: InsertState): Promise<State>;
  
  // LOB methods
  getLobs(): Promise<Lob[]>;
  getLob(id: number): Promise<Lob | undefined>;
  createLob(lob: InsertLob): Promise<Lob>;
  
  // LOC methods
  getLocs(): Promise<Loc[]>;
  getLoc(id: number): Promise<Loc | undefined>;
  createLoc(loc: InsertLoc): Promise<Loc>;
  
  // Holiday methods
  getHolidays(): Promise<Holiday[]>;
  getHolidaysByYear(year: number): Promise<Holiday[]>;
  getHolidaysByState(stateId: number): Promise<Holiday[]>;
  getHolidaysByYearAndState(year: number, stateId: number): Promise<Holiday[]>;
  getHolidaysByLob(lobId: number): Promise<Holiday[]>;
  getHolidaysByLoc(locId: number): Promise<Holiday[]>;
  getHoliday(id: number): Promise<Holiday | undefined>;
  createHoliday(holiday: InsertHoliday): Promise<Holiday>;
  
  // Associations
  addHolidayState(holidayState: InsertHolidayState): Promise<HolidayState>;
  addHolidayLob(holidayLob: InsertHolidayLob): Promise<HolidayLob>;
  addHolidayLoc(holidayLoc: InsertHolidayLoc): Promise<HolidayLoc>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private states: Map<number, State>;
  private lobs: Map<number, Lob>;
  private locs: Map<number, Loc>;
  private holidays: Map<number, Holiday>;
  private holidayStates: Map<number, HolidayState>;
  private holidayLobs: Map<number, HolidayLob>;
  private holidayLocs: Map<number, HolidayLoc>;
  
  private currentUserId: number;
  private currentStateId: number;
  private currentLobId: number;
  private currentLocId: number;
  private currentHolidayId: number;
  private currentHolidayStateId: number;
  private currentHolidayLobId: number;
  private currentHolidayLocId: number;

  constructor() {
    this.users = new Map();
    this.states = new Map();
    this.lobs = new Map();
    this.locs = new Map();
    this.holidays = new Map();
    this.holidayStates = new Map();
    this.holidayLobs = new Map();
    this.holidayLocs = new Map();
    
    this.currentUserId = 1;
    this.currentStateId = 1;
    this.currentLobId = 1;
    this.currentLocId = 1;
    this.currentHolidayId = 1;
    this.currentHolidayStateId = 1;
    this.currentHolidayLobId = 1;
    this.currentHolidayLocId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  // Initialize with sample data
  private initializeData() {
    // States
    const states = [
      { name: "All States", code: "ALL" },
      { name: "Maharashtra", code: "MH" },
      { name: "Karnataka", code: "KA" },
      { name: "Tamil Nadu", code: "TN" },
      { name: "Delhi", code: "DL" },
      { name: "Uttar Pradesh", code: "UP" }
    ];
    
    states.forEach(state => {
      this.createState({ name: state.name, code: state.code });
    });
    
    // LOBs
    const lobs = [
      { name: "All Categories", code: "ALL" },
      { name: "Banking", code: "BANK" },
      { name: "Insurance", code: "INS" },
      { name: "Healthcare", code: "HEALTH" },
      { name: "Technology", code: "TECH" }
    ];
    
    lobs.forEach(lob => {
      this.createLob({ name: lob.name, code: lob.code });
    });
    
    // LOCs
    const locs = [
      { name: "All Locations", code: "ALL" },
      { name: "Mumbai", code: "MUM" },
      { name: "Bangalore", code: "BLR" },
      { name: "Chennai", code: "CHN" },
      { name: "Delhi", code: "DEL" }
    ];
    
    locs.forEach(loc => {
      this.createLoc({ name: loc.name, code: loc.code });
    });
    
    // Holidays
    const today = new Date();
    const currentYear = today.getFullYear();
    
    const holidays = [
      { 
        name: "New Year's Day", 
        date: new Date(currentYear, 0, 1), 
        description: "New Year's Day is the first day of the year in the Gregorian calendar.", 
        type: HolidayType.NATIONAL 
      },
      { 
        name: "Republic Day", 
        date: new Date(currentYear, 0, 26), 
        description: "Republic Day honors the date on which the Constitution of India came into effect, replacing the Government of India Act as the governing document of India.", 
        type: HolidayType.NATIONAL 
      },
      { 
        name: "Maharashtra Day", 
        date: new Date(currentYear, 4, 1), 
        description: "Maharashtra Day marks the formation of the state of Maharashtra.", 
        type: HolidayType.REGIONAL 
      },
      { 
        name: "Independence Day", 
        date: new Date(currentYear, 7, 15), 
        description: "Independence Day is celebrated annually on 15 August to commemorate India's independence from British rule.", 
        type: HolidayType.NATIONAL 
      },
      { 
        name: "Gandhi Jayanti", 
        date: new Date(currentYear, 9, 2), 
        description: "Gandhi Jayanti is celebrated yearly to mark the birth anniversary of Mahatma Gandhi.", 
        type: HolidayType.OBSERVANCE 
      },
      { 
        name: "Christmas", 
        date: new Date(currentYear, 11, 25), 
        description: "Christmas is an annual festival commemorating the birth of Jesus Christ.", 
        type: HolidayType.NATIONAL 
      }
    ];
    
    holidays.forEach(holiday => {
      const newHoliday = this.createHoliday({
        name: holiday.name,
        date: holiday.date,
        description: holiday.description,
        type: holiday.type
      });
      
      // Associate regional holidays with specific states
      if (holiday.name === "Maharashtra Day") {
        this.addHolidayState({ holidayId: newHoliday.id, stateId: 2 }); // Maharashtra
      } else {
        // Add national holidays to all states
        for (let i = 1; i <= states.length; i++) {
          this.addHolidayState({ holidayId: newHoliday.id, stateId: i });
        }
      }
      
      // Associate all holidays with all LOBs and LOCs for demonstration
      for (let i = 1; i <= lobs.length; i++) {
        this.addHolidayLob({ holidayId: newHoliday.id, lobId: i });
      }
      
      for (let i = 1; i <= locs.length; i++) {
        this.addHolidayLoc({ holidayId: newHoliday.id, locId: i });
      }
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // State methods
  async getStates(): Promise<State[]> {
    return Array.from(this.states.values());
  }
  
  async getState(id: number): Promise<State | undefined> {
    return this.states.get(id);
  }
  
  async createState(insertState: InsertState): Promise<State> {
    const id = this.currentStateId++;
    const state: State = { ...insertState, id };
    this.states.set(id, state);
    return state;
  }
  
  // LOB methods
  async getLobs(): Promise<Lob[]> {
    return Array.from(this.lobs.values());
  }
  
  async getLob(id: number): Promise<Lob | undefined> {
    return this.lobs.get(id);
  }
  
  async createLob(insertLob: InsertLob): Promise<Lob> {
    const id = this.currentLobId++;
    const lob: Lob = { ...insertLob, id };
    this.lobs.set(id, lob);
    return lob;
  }
  
  // LOC methods
  async getLocs(): Promise<Loc[]> {
    return Array.from(this.locs.values());
  }
  
  async getLoc(id: number): Promise<Loc | undefined> {
    return this.locs.get(id);
  }
  
  async createLoc(insertLoc: InsertLoc): Promise<Loc> {
    const id = this.currentLocId++;
    const loc: Loc = { ...insertLoc, id };
    this.locs.set(id, loc);
    return loc;
  }
  
  // Holiday methods
  async getHolidays(): Promise<Holiday[]> {
    return Array.from(this.holidays.values());
  }
  
  async getHolidaysByYear(year: number): Promise<Holiday[]> {
    return Array.from(this.holidays.values()).filter(holiday => {
      const holidayDate = new Date(holiday.date);
      return holidayDate.getFullYear() === year;
    });
  }
  
  async getHolidaysByState(stateId: number): Promise<Holiday[]> {
    // If "All States" is selected, return all holidays
    if (stateId === 1) {
      return this.getHolidays();
    }
    
    // Get all holiday-state associations for the given state
    const stateAssociations = Array.from(this.holidayStates.values())
      .filter(association => association.stateId === stateId);
    
    // Get the holidays for those associations
    const holidays: Holiday[] = [];
    for (const association of stateAssociations) {
      const holiday = this.holidays.get(association.holidayId);
      if (holiday) {
        holidays.push(holiday);
      }
    }
    
    return holidays;
  }
  
  async getHolidaysByYearAndState(year: number, stateId: number): Promise<Holiday[]> {
    const stateHolidays = await this.getHolidaysByState(stateId);
    
    return stateHolidays.filter(holiday => {
      const holidayDate = new Date(holiday.date);
      return holidayDate.getFullYear() === year;
    });
  }
  
  async getHolidaysByLob(lobId: number): Promise<Holiday[]> {
    // If "All Categories" is selected, return all holidays
    if (lobId === 1) {
      return this.getHolidays();
    }
    
    // Get all holiday-lob associations for the given lob
    const lobAssociations = Array.from(this.holidayLobs.values())
      .filter(association => association.lobId === lobId);
    
    // Get the holidays for those associations
    const holidays: Holiday[] = [];
    for (const association of lobAssociations) {
      const holiday = this.holidays.get(association.holidayId);
      if (holiday) {
        holidays.push(holiday);
      }
    }
    
    return holidays;
  }
  
  async getHolidaysByLoc(locId: number): Promise<Holiday[]> {
    // If "All Locations" is selected, return all holidays
    if (locId === 1) {
      return this.getHolidays();
    }
    
    // Get all holiday-loc associations for the given loc
    const locAssociations = Array.from(this.holidayLocs.values())
      .filter(association => association.locId === locId);
    
    // Get the holidays for those associations
    const holidays: Holiday[] = [];
    for (const association of locAssociations) {
      const holiday = this.holidays.get(association.holidayId);
      if (holiday) {
        holidays.push(holiday);
      }
    }
    
    return holidays;
  }
  
  async getHoliday(id: number): Promise<Holiday | undefined> {
    return this.holidays.get(id);
  }
  
  async createHoliday(insertHoliday: InsertHoliday): Promise<Holiday> {
    const id = this.currentHolidayId++;
    const holiday: Holiday = { ...insertHoliday, id };
    this.holidays.set(id, holiday);
    return holiday;
  }
  
  // Associations
  async addHolidayState(insertHolidayState: InsertHolidayState): Promise<HolidayState> {
    const id = this.currentHolidayStateId++;
    const holidayState: HolidayState = { ...insertHolidayState, id };
    this.holidayStates.set(id, holidayState);
    return holidayState;
  }
  
  async addHolidayLob(insertHolidayLob: InsertHolidayLob): Promise<HolidayLob> {
    const id = this.currentHolidayLobId++;
    const holidayLob: HolidayLob = { ...insertHolidayLob, id };
    this.holidayLobs.set(id, holidayLob);
    return holidayLob;
  }
  
  async addHolidayLoc(insertHolidayLoc: InsertHolidayLoc): Promise<HolidayLoc> {
    const id = this.currentHolidayLocId++;
    const holidayLoc: HolidayLoc = { ...insertHolidayLoc, id };
    this.holidayLocs.set(id, holidayLoc);
    return holidayLoc;
  }
}

export const storage = new MemStorage();
