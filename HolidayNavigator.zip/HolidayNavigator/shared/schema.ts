import { pgTable, text, serial, integer, boolean, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Holiday types
export enum HolidayType {
  NATIONAL = "NATIONAL",
  REGIONAL = "REGIONAL",
  OBSERVANCE = "OBSERVANCE"
}

// States table
export const states = pgTable("states", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  code: text("code").notNull().unique(),
});

export const insertStateSchema = createInsertSchema(states).pick({
  name: true,
  code: true,
});

export type InsertState = z.infer<typeof insertStateSchema>;
export type State = typeof states.$inferSelect;

// LOB (Line of Business) table
export const lobs = pgTable("lobs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  code: text("code").notNull().unique(),
});

export const insertLobSchema = createInsertSchema(lobs).pick({
  name: true,
  code: true,
});

export type InsertLob = z.infer<typeof insertLobSchema>;
export type Lob = typeof lobs.$inferSelect;

// LOC (Line of Code) table
export const locs = pgTable("locs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  code: text("code").notNull().unique(),
});

export const insertLocSchema = createInsertSchema(locs).pick({
  name: true,
  code: true,
});

export type InsertLoc = z.infer<typeof insertLocSchema>;
export type Loc = typeof locs.$inferSelect;

// Holidays table
export const holidays = pgTable("holidays", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  date: date("date").notNull(),
  description: text("description"),
  type: text("type").notNull(), // NATIONAL, REGIONAL, OBSERVANCE
});

export const insertHolidaySchema = createInsertSchema(holidays).pick({
  name: true,
  date: true,
  description: true,
  type: true,
});

export type InsertHoliday = z.infer<typeof insertHolidaySchema>;
export type Holiday = typeof holidays.$inferSelect;

// Holiday-State association table (for regional holidays)
export const holidayStates = pgTable("holiday_states", {
  id: serial("id").primaryKey(),
  holidayId: integer("holiday_id").notNull(),
  stateId: integer("state_id").notNull(),
});

export const insertHolidayStateSchema = createInsertSchema(holidayStates).pick({
  holidayId: true,
  stateId: true,
});

export type InsertHolidayState = z.infer<typeof insertHolidayStateSchema>;
export type HolidayState = typeof holidayStates.$inferSelect;

// Holiday-LOB association table
export const holidayLobs = pgTable("holiday_lobs", {
  id: serial("id").primaryKey(),
  holidayId: integer("holiday_id").notNull(),
  lobId: integer("lob_id").notNull(),
});

export const insertHolidayLobSchema = createInsertSchema(holidayLobs).pick({
  holidayId: true,
  lobId: true,
});

export type InsertHolidayLob = z.infer<typeof insertHolidayLobSchema>;
export type HolidayLob = typeof holidayLobs.$inferSelect;

// Holiday-LOC association table
export const holidayLocs = pgTable("holiday_locs", {
  id: serial("id").primaryKey(),
  holidayId: integer("holiday_id").notNull(),
  locId: integer("loc_id").notNull(),
});

export const insertHolidayLocSchema = createInsertSchema(holidayLocs).pick({
  holidayId: true,
  locId: true,
});

export type InsertHolidayLoc = z.infer<typeof insertHolidayLocSchema>;
export type HolidayLoc = typeof holidayLocs.$inferSelect;
